package com.firefly.utils.pool;

public interface ObjectFactory {
	Poolable newInstance();
}
