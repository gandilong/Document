package com.firefly.utils.log;

public class LogException extends RuntimeException {

	private static final long serialVersionUID = -4932202708783665424L;

	public LogException(String msg) {
		super(msg);
	}
}
