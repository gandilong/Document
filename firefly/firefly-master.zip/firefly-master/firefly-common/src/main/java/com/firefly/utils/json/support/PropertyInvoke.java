package com.firefly.utils.json.support;

public interface PropertyInvoke {
	
	void set(Object obj, Object arg);
	
	Object get(Object obj);
}
