package com.firefly.utils.io;

public interface LineReaderHandler {
	void readline(String text, int num);
}
