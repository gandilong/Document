package test.utils.json;

public class ArrayObj {
	private Integer[] numbers;
	private long[][] map;
	private User[] users;

	public long[][] getMap() {
		return map;
	}

	public void setMap(long[][] map) {
		this.map = map;
	}

	public Integer[] getNumbers() {
		return numbers;
	}

	public void setNumbers(Integer[] numbers) {
		this.numbers = numbers;
	}

	public User[] getUsers() {
		return users;
	}

	public void setUsers(User[] users) {
		this.users = users;
	}

}
