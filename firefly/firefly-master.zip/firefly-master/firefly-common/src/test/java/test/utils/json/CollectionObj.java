package test.utils.json;

import java.util.LinkedList;
import java.util.List;

public class CollectionObj {
	private List<LinkedList<SimpleObj>> list;

	public List<LinkedList<SimpleObj>> getList() {
		return list;
	}

	public void setList(List<LinkedList<SimpleObj>> list) {
		this.list = list;
	}

}
