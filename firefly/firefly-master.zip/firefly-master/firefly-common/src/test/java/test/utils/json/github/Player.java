package test.utils.json.github;

public enum Player {

    JAVA, FLASH
}
