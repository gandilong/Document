package test.utils.json.github;

public class Image {

    private String uri;

    private String title;

    private int width;

    private int height;

    private Size size;

    public String getUri() {
        return uri;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public Size getSize() {
        return size;
    }

    public void setSize(Size Size) {
        this.size = Size;
    }
}
