package test.utils.json.github;

public class MediaRecord {

    private String value1;

    private String value2;

    private int value3;

    private int value4;

    private String value5;

    private long value6;

    private long value7;

    private int value8;

    private String[] value9;

    private Player value10;

    private String value11;

    public String getValue1() {
        return value1;
    }

    public void setValue1(String value1) {
        this.value1 = value1;
    }

    public String getValue2() {
        return value2;
    }

    public void setValue2(String value2) {
        this.value2 = value2;
    }

    public int getValue3() {
        return value3;
    }

    public void setValue3(int value3) {
        this.value3 = value3;
    }

    public int getValue4() {
        return value4;
    }

    public void setValue4(int value4) {
        this.value4 = value4;
    }

    public String getValue5() {
        return value5;
    }

    public void setValue5(String value5) {
        this.value5 = value5;
    }

    public long getValue6() {
        return value6;
    }

    public void setValue6(long value6) {
        this.value6 = value6;
    }

    public long getValue7() {
        return value7;
    }

    public void setValue7(long value7) {
        this.value7 = value7;
    }

    public int getValue8() {
        return value8;
    }

    public void setValue8(int value8) {
        this.value8 = value8;
    }

    public String[] getValue9() {
        return value9;
    }

    public void setValue9(String[] value9) {
        this.value9 = value9;
    }

    public Player getValue10() {
        return value10;
    }

    public void setValue10(Player value10) {
        this.value10 = value10;
    }

    public String getValue11() {
        return value11;
    }

    public void setValue11(String value11) {
        this.value11 = value11;
    }
}
