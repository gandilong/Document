package test.utils.json;

public class SimpleObj2 {
	private Integer id;
	private User user;
	private Book book;
	private char sex;
	private char[] symbol;

	public char[] getSymbol() {
		return symbol;
	}

	public void setSymbol(char[] symbol) {
		this.symbol = symbol;
	}

	public char getSex() {
		return sex;
	}

	public void setSex(char sex) {
		this.sex = sex;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Book getBook() {
		return book;
	}

	public void setBook(Book book) {
		this.book = book;
	}

}
