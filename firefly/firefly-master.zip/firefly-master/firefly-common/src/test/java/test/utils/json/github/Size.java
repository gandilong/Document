package test.utils.json.github;

public enum Size {

    SMALL, LARGE
}
