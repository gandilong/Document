package com.firefly.net.udp;

import com.firefly.net.Client;
import com.firefly.net.Config;

public class UdpClient implements Client {

	@Override
	public void setConfig(Config config) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int connect(String host, int port) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void shutdown() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void connect(String host, int port, int id) {
		// TODO Auto-generated method stub
		
	}


}
