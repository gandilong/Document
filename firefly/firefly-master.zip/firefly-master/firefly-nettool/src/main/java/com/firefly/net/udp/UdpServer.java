package com.firefly.net.udp;

import com.firefly.net.Config;
import com.firefly.net.Server;

public class UdpServer implements Server {

	@Override
	public void setConfig(Config config) {
		// TODO Auto-generated method stub
		
	}

    @Override
    public void start(String host, int port) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

	@Override
	public void shutdown() {
		// TODO Auto-generated method stub
		
	}

}
