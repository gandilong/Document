package test.component3;

import java.util.Map;

public class MapService {
	private Map<Object, Object> map;

	public Map<Object, Object> getMap() {
		return map;
	}

	public void setMap(Map<Object, Object> map) {
		this.map = map;
	}

}
