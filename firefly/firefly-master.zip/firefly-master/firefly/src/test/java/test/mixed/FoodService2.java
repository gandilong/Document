package test.mixed;

public interface FoodService2 {
	Food getFood(String name);
}
