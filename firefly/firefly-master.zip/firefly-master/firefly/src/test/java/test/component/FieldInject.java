package test.component;

public interface FieldInject {
	int add(int x, int y);

	int add2(int x, int y);
}
