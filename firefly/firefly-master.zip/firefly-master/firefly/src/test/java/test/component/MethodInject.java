package test.component;

public interface MethodInject {
	int add(int x, int y);
}
