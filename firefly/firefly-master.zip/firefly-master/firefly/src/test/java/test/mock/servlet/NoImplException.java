package test.mock.servlet;

public class NoImplException extends RuntimeException {

	private static final long serialVersionUID = -530610412864911395L;

	public NoImplException() {
		super();
	}

	public NoImplException(String msg) {
		super(msg);
	}

}
