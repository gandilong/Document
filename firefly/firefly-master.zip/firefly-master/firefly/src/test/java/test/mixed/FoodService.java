package test.mixed;

public interface FoodService {
	Food getFood(String name);
}
