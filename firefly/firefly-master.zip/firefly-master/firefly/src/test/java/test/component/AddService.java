package test.component;

public interface AddService {
	int add(int x, int y);

	int getI();
}
