package test.mixed;

import java.util.List;


public interface FoodRepository {
	List<Food> getFood();
}
