package test.component2;

public interface MethodInject2 {
	int add(int x, int y);

	Integer getNum();
}
