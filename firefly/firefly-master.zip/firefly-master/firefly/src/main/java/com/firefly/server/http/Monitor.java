package com.firefly.server.http;

import java.util.concurrent.atomic.AtomicInteger;

public class Monitor {
	public static final AtomicInteger CONN_COUNT = new AtomicInteger();
}
