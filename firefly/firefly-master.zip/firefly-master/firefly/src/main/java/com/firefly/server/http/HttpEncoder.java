package com.firefly.server.http;

import com.firefly.net.Encoder;
import com.firefly.net.Session;

public class HttpEncoder implements Encoder {

	@Override
	public void encode(Object message, Session session) throws Throwable {
		// TODO Auto-generated method stub

	}

}
