package com.firefly.core.support.xml;

import java.util.ArrayList;

/**
 * array元素
 * @author alvinqiu
 */
public class ManagedArray<T> extends ArrayList<T> {

	private static final long serialVersionUID = -3015988166845274665L;

}
