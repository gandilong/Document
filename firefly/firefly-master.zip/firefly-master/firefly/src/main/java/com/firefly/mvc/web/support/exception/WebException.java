package com.firefly.mvc.web.support.exception;

public class WebException extends RuntimeException {

	private static final long serialVersionUID = 5463739797601360583L;

	public WebException(String msg) {
		super(msg);
	}
}
