alter table ACT_RU_TASK 
add PARENT_TASK_ID_ nvarchar(64);
