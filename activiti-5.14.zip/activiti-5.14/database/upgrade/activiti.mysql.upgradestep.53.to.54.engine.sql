alter table ACT_RU_TASK 
add OWNER_ varchar(64);

alter table ACT_RU_TASK 
add DELEGATION_ varchar(64);

alter table ACT_RU_TASK 
add DUE_DATE_ datetime;